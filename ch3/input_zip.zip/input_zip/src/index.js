import React from 'react'
import ReactDOM from 'react-dom'
import ZipInput from './ZipInput'

ReactDOM.render(
  <div><ZipInput /></div>,
  document.getElementById('root')
)